package com.luminous.notekeeper;

import static org.junit.Assert.*;

public class NoteCreationTest {

}